/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author oem
 */
public class Coache {
    private String name;
    private String address;
    public void setName(String x){
        name=x;
}
    public String getName(){
        return name;
    }
    public void setAddress(String x){
        address=x;
}
    public String getAddress(){
        return address;
    }
    public Coache(){
        
    }
}
