/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author oem
 */
public class Medal {
    private String type;
    public void setName(String x){
        type=x;
}
    public String getName(){
        return type;
    }
    public Medal(){
        
    }
}
